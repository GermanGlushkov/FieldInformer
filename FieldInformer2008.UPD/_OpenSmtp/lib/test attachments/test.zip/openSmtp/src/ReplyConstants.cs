namespace openSmtp

{

/****************************************************
SmtpConstants.cs
Updated: 1/17/2002
Author: Ian Stallings - jovian_moon@hotmail.com

This is a Email Address
*****************************************************/

using System;

	internal class ReplyConstants
	{
		private ReplyConstants()
		{}

		public static readonly String SYSTEM_STATUS					= "211";
		public static readonly String HELP_MSG						= "214";
		public static readonly String HELO_REPLY 					= "220";
		public static readonly String QUIT 							= "221";
		public static readonly String OK 							= "250";
		public static readonly String NOT_LOCAL_WILL_FORWARD		= "251";
		public static readonly String START_INPUT 					= "354";
		public static readonly String SERVICE_NOT_AVAILABLE			= "421";
		public static readonly String MAILBOX_BUSY 					= "450";
		public static readonly String ERROR_PROCESSING				= "451";
		public static readonly String INSUFFICIENT_STORAGE			= "452";
		public static readonly String UNKNOWN 						= "500";
		public static readonly String SYNTAX_ERROR					= "501";
		public static readonly String CMD_NOT_IMPLEMENTED			= "502";
		public static readonly String BAD_SEQUENCE					= "503";
		public static readonly String PAR_NOT_IMPLEMENTED			= "504";
		public static readonly String SECURITY_ERROR 				= "505";
		public static readonly String ACTION_NOT_TAKEN 				= "550";
		public static readonly String NOT_LOCAL_PLEASE_FORWARD 		= "551";
		public static readonly String EXCEEDED_STORAGE_ALLOWANCE	= "552";
		public static readonly String MAILBOX_NAME_NOT_ALLOWED		= "553";
		public static readonly String TRANSACTION_FAILED			= "554";

	}
	
}