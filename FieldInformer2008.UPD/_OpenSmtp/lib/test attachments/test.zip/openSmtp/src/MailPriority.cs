namespace openSmtp 
{

/****************************************************
MailPriority.cs
Updated: 1/21/2002
Author: Ian Stallings - jovian_moon@hotmail.com

This is a MailPriority class that stores the constants 
for Mail Priority message settings.
*****************************************************/

using System;

	public class MailPriority
	{

		public static readonly string HIGHEST   = 	"1";
		public static readonly string HIGH   	= 	"2";
		public static readonly string NORMAL 	= 	"3";
		public static readonly string LOW   	=	"4";
		public static readonly string LOWEST    =	"5";
	
		private MailPriority() 
		{}
	
	}
}
	
