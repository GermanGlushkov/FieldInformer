namespace openSmtp 
{

/****************************************************
SmtpException.cs
Updated: 1/21/2002
Author: Ian Stallings - jovian_moon@hotmail.com

This is a SmtpException class.
*****************************************************/

using System;

// exception for transport class (smtp):

	public class SmtpException:Exception
	{
		private string error;
	
		public SmtpException()
		{}
		
		
		public SmtpException(string s)
		{
			error = s;
		}

		public SmtpException(string s, Exception e)
		{
			error = s;
		}

		
		public string Error
		{
			get { return(this.error); }
		}
		
	}
	
}