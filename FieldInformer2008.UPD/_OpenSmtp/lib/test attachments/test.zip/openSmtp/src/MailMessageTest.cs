namespace openSmtp.test {

using NUnit.Framework;
using openSmtp;
using System;




/*

openSmtpTest.dll
Author: Ian Stallings - jovian_moon@hotmail.com 
Notes: 	Unit test for the MailMessage class using the NUnit framework
http://sourceforge.net/projects/nunit/

*/

	public class MailMessageTest: TestCase 
	{
		private MailMessage msg;
		private Address senderAddress;
		private Address recipientAddress;
		private string sender;
		private string senderName;
		private string recipient;
		private string recipientName;
		private string subject;
		private string body;


		public MailMessageTest (string name) : base(name) {}
		        
		protected override void SetUp() 
		{
			sender 			= 	"administrator@localhost";
			senderName 		= 	"John Doe";
			recipient		= 	"dork@localhost";
			recipientName	= 	"Jane Smith";
			subject			= 	"Mail Message Test";
			body			=	"Hello from MailMessageTest";

			
			Address senderAddress 		= new Address(sender, senderName);
			//Address recipientAddress 	= new Address(recipient, recipientName);
			
			//MailMessage msg 			= new MailMessage(senderAddress, recipientAddress);
				
		}
		
		protected override void TearDown()
		{}
    		
    		

		public static ITest Suite 
		{
			get { return new TestSuite(typeof (MailMessageTest));}
		}	
	
	
		// Test MailMessage class below:
		
		public void testSenderAddress()
		{
			
			string s = msg.getFrom().getPersonal();
			Assert(sender.Equals(s));
			
		}
	
	
		public void testReplyToAddress()
		{
			
		//	string returnedSender = msg.getReplyTo().getAddress();
		//	AssertEquals(senderAddress, returnedSender);
			
		}
	
		public void testRecipientAddress()
		{
		
//			string returnedRecipient = msg.getTo().getAddress();
//			AssertEquals(recipientAddress, returnedRecipient);
		}
		
		public void testSubject()
		{

//			msg.setSubject(subject);
//			string returnedSubject = msg.getSubject();
//			AssertEquals(subject, returnedSubject);
		}

		public void testBody()
		{

//			msg.setBody(body);
//			string returnedBody = msg.getBody();
//			AssertEquals(body, returnedBody);
		}
	
	
	}
	
}