namespace openSmtp
{

/*

Author: Ian Stallings - jovian_moon@hotmail.com  -

*/


using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
 
	public class Crypto
	{
		private ToBase64Transform transformer;
		
		public Crypto() 
		{}
		
		
		/// <summary> encodes a String using Base64</summary>
 		public String convertBase64(String s)
		{
			transformer = new ToBase64Transform();
			Byte[] from = Encoding.ASCII.GetBytes(s.ToCharArray());
			Byte[] to = new byte[from.Length];
			int totalWritten = transformer.TransformBlock(from, 0, from.Length, to, to.Length);
		//	String encoded = Encoding.ASCII.GetString(to);
			
			return null;
		}
		

		/// <summary> encodes a fileStream using Base64</summary>
 		public void convertBase64(String inputFilePath, String outputFilePath)
		{
			//Create the file streams to handle the input and output files.
			FileStream fin = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read);
			FileStream fout = new FileStream(outputFilePath, FileMode.OpenOrCreate, FileAccess.Write);
			fout.SetLength(0);

			//Create variables to help with read and write.
			byte[] bin = new byte[4096]; //This is intermediate storage for the encryption.
			long rdlen = 8;              //This is the total number of bytes written.
			long totlen = fin.Length;    //This is the total length of the input file.
			int len;                     //This is the number of bytes to be written at a time.
 
			transformer = new ToBase64Transform();
			CryptoStream encStream = new CryptoStream(fout, transformer, CryptoStreamMode.Write);
 
			//Read from the input file, then encrypt and write to the output file.
			while(rdlen < totlen)
			{
				len = fin.Read(bin, 0, 4096);
				encStream.Write(bin, 0, len);
				//inputBlock size(3)
				rdlen = (rdlen + ((len / transformer.InputBlockSize) * transformer.OutputBlockSize));
			//	Console.WriteLine("Processed {0} bytes, {1} bytes total", len, rdlen);
			}
 
			encStream.Close();    
		}
	}

}