namespace openSmtp 
{

/****************************************************
Smtp.cs
Updated: 1/21/2002
Author: Ian Stallings - jovian_moon@hotmail.com

This is a Smtp class. The main class used to send an 
email via smtp
*****************************************************/


using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Collections;

	public class Smtp
	{
		private string smtpHost;
		private int smtpPort;
		
		// default tcp timeouts to 20 seconds
		private int tcpSendTimeout = 20;
		private int tcpRecieveTimeout = 20;
		
		
		public Smtp() 
		{}
		
		public Smtp(string host, int port) 
		{
			this.smtpHost = host;
			this.smtpPort = port;
		}

		public string Host
		{
			get { return(this.smtpHost); }
			set { this.smtpHost = value; }
		}		

		public int Port
		{
			get { return(this.smtpPort); }
			set { this.smtpPort = value; }
		}
		
		public int SendTimeout
		{
			get { return this.tcpSendTimeout; }
			set { tcpSendTimeout = value; }
		
		}

		public int RecieveTimeout
		{
			get { return this.tcpRecieveTimeout; }
			set { tcpRecieveTimeout = value; }
		
		}


		public void SendMail(MailMessage msg)
			
		{
		
			TcpClient tcpc = new TcpClient();

			try
			{
				if (smtpHost == null)
				{ smtpHost = SmtpConfig.SMTP_HOST; }
				
				if (smtpPort == 0)
				{ smtpPort = SmtpConfig.SMTP_PORT; }
				
				
				if (smtpHost != null && smtpPort != 0)
				{
					tcpc.Connect(smtpHost, smtpPort);
					LogMessage("connecting to:" + smtpHost + ":" + smtpPort, "-----"); 
					tcpc.ReceiveTimeout= tcpRecieveTimeout;
					tcpc.SendTimeout = tcpSendTimeout;
				}
				else
				{
					throw new SmtpException("Cannot use sendMail() method without specifying target host and port");
				}
				
				NetworkStream nwstream = tcpc.GetStream();
				CheckForError(ReadFromStream(ref nwstream), ReplyConstants.HELO_REPLY);

				WriteToStream(ref nwstream, "EHLO " + smtpHost + "\r\n");
				string welcomeMsg = ReadFromStream(ref nwstream);

				// implement HELO command if EHLO is unrecognized.
				if (IsUnknownCommand(welcomeMsg))
				{
					WriteToStream(ref nwstream, "HELO " + smtpHost + "\r\n");
				
				}
				
				CheckForError(welcomeMsg, ReplyConstants.OK);

				WriteToStream(ref nwstream, "MAIL FROM: <" + msg.From.Address + ">\r\n");
				CheckForError(ReadFromStream(ref nwstream), ReplyConstants.OK);

				SendRecipientList(ref nwstream, msg.To);
				SendRecipientList(ref nwstream, msg.CC);
				SendRecipientList(ref nwstream, msg.BCC);

				WriteToStream(ref nwstream, "DATA\r\n");
				CheckForError(ReadFromStream(ref nwstream), ReplyConstants.START_INPUT);

				if (msg.ReplyTo.Name != null && msg.ReplyTo.Name.Length != 0)
					{ WriteToStream(ref nwstream, "Reply-To: \"" + msg.ReplyTo.Name + "\" <" + msg.ReplyTo.Address + ">\r\n"); }
				else
					{ WriteToStream(ref nwstream, "Reply-To: <" + msg.ReplyTo.Address + ">\r\n"); }
					
				if (msg.From.Name != null && msg.From.Name.Length != 0)
					{ WriteToStream(ref nwstream, "From: \"" + msg.From.Name + "\" <" + msg.From.Address + ">\r\n"); }
				else
					{ WriteToStream(ref nwstream, "From: <" + msg.From.Address + ">\r\n"); }
				
				WriteToStream(ref nwstream, "To: " + CreateAddressList(msg.To) + "\r\n");
				
				if (msg.CC.Count != 0)
					{ WriteToStream(ref nwstream, "CC: " + CreateAddressList(msg.CC) + "\r\n"); }

				WriteToStream(ref nwstream, "Subject: " + msg.Subject + "\r\n");

				if (msg.Priority != null)
				{ WriteToStream(ref nwstream, "X-Priority: " + msg.Priority + "\r\n"); }
				

				WriteToStream(ref nwstream, msg.Body + "\r\n");
				WriteToStream(ref nwstream, "\r\n.\r\n");
				CheckForError(ReadFromStream(ref nwstream), ReplyConstants.OK);

		
				WriteToStream(ref nwstream, "QUIT\r\n");
				CheckForError(ReadFromStream(ref nwstream), ReplyConstants.QUIT);

			}
			catch(SocketException e)
			{

				throw new SmtpException("Cannot connect to specified smtp host(" + smtpHost + ":" + smtpPort + ").", e);

			}
			finally
			{
				LogMessage("------------------------------------------------------", "");
				tcpc.Close();
			}
		}
		
		
		
		// --------------- Helper methods ------------------------------------
		
		// creates comma seperated address list from to: and cc:
		private string CreateAddressList(ArrayList msgList)
		{
			StringBuilder sb = new StringBuilder();

			int index = 1;
			int msgCount = msgList.Count;
			
			for (IEnumerator i = msgList.GetEnumerator(); i.MoveNext(); index++)
			{
				EmailAddress a = (EmailAddress)i.Current;
				

				// if the personal name exists, add it to the address sent. IE: "Ian Stallings" <istallings@mail.com>
				if (a.Name != null && a.Name.Length > 0)
				{
					sb.Append("\"" + a.Name + "\" <" + a.Address + ">");
				}
				else
				{
					sb.Append("<" + a.Address + ">");
				}

				
				// if it's not the last address add a semi-colon:
				if (msgCount != index) 
				{
					sb.Append(";");
				}
				
			}		
			
			return sb.ToString();
		}
		
		private void SendRecipientList(ref NetworkStream nwstream, ArrayList recipients)
		{
			//	Iterate through all addresses and send them:
			for (IEnumerator i = recipients.GetEnumerator();i.MoveNext();)
			{
				EmailAddress recipient = (EmailAddress)i.Current;
				WriteToStream(ref nwstream, "RCPT TO: <" + recipient.Address + ">\r\n");

				// potential 501 error (not valid sender) below:
				CheckForError(ReadFromStream(ref nwstream), ReplyConstants.OK);
			}	
		}

		private bool checkMailMessage(MailMessage message)
		{
			string returnMessage = "Mail Message is missing ";
		
			if (message.To == null)
			{	throw new SmtpException(returnMessage + "'To:' field");
				return false;
			}
			else
			{ return true; }
		}

		/**
		 * NetworkStream Helper methods
		 */
		private void WriteToStream(ref NetworkStream nw, string line)
		{
				Byte[] arrToSend = Encoding.ASCII.GetBytes(line);
				nw.Write(arrToSend, 0, arrToSend.Length);

				LogMessage(line, "[client]: ");
		}

		private string ReadFromStream(ref NetworkStream nw)
		{
			byte[] readBuffer = new byte[1024];
			int length = nw.Read(readBuffer, 0, readBuffer.Length);
			string returnMsg = Encoding.ASCII.GetString(readBuffer, 0, length);
			LogMessage(returnMsg, "[server]: ");

			return returnMsg;
		}

		private void LogMessage(string msg, string src)
		{
			Log log = new Log();
			log.logToTextFile(SmtpConfig.SMTP_LOG_PATH, msg, src);
			if (SmtpConfig.EVENT_LOG) { log.logToEventLog(msg, src); }
		}


		/**
		 *
		 * Checks stream returned from SMTP server for success code
		 * If the success code is not present it will throw an error.		
		 *
		 */
		private void CheckForError(string s, string successCode)
		{
			if (s.IndexOf(successCode) == -1)
				throw new SmtpException("ERROR - Expecting " + successCode + ". Recieved: " + s);
		}


		private bool IsUnknownCommand(string s)
		{
			if (s.IndexOf(ReplyConstants.UNKNOWN) == -1) { return false; }
			else { return true; }
			return false;
		}


	}
	
}