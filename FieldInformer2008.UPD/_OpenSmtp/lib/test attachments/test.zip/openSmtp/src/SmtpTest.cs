namespace openSmtp.test {


using NUnit.Framework;
using openSmtp;

using System;
using System.Configuration;

/*

openSmtpTest.dll
Ian Stallings - jovian_moon@hotmail.com 


Unit test for the Smtp class using the NUnit framework
http://sourceforge.net/projects/nunit/

*/

	public class SmtpTest: TestCase 
	{
			private int 			smtpPort;
			private string 			smtpHost;
			private int				recieveTimeout;
			private int				sendTimeout;

			private string 			subject;
			private string 			body;
			private string			priority;

			private Smtp 			smtp;
			private MailMessage 	msg;
			private EmailAddress	senderAddress;
			private EmailAddress	additionalAddress;
			private EmailAddress 	replyToAddress;
			private EmailAddress 	recipientAddress;
			private EmailAddress 	ccAddress;
			private EmailAddress	bccAddress;

			// ---------------------------------------------------------------

			public SmtpTest (string name) : base(name) {}

		
			public static ITest Suite 
			{
				get { return new TestSuite(typeof (SmtpTest));}
			}

			// ---------------------------------------------------------------			

			protected override void SetUp() 
			{
				subject 			= "test subject";
				body 				= "Hello Jane.\r\n This is the body of the mail message.";		
				
				senderAddress 		= new EmailAddress("admininstrator@localhost.com", "Sender Name");
				additionalAddress	= new EmailAddress("additional@localhost", "Second Name");
				recipientAddress 	= new EmailAddress("recipient@localhost.com", "Recipient Name");
				replyToAddress 		= new EmailAddress("replyTo@localhost.com", "ReplyTo Name");
				ccAddress 			= new EmailAddress("ccAddress@localhost", "CC Name");
				bccAddress			= new EmailAddress("bccAddress@localhost", "BCC Name");
				
			
				smtpHost 			= "localhost";
				smtpPort 			= 25;
				sendTimeout			= 30;
				recieveTimeout		= 30;
				
				smtp 				= new Smtp(smtpHost, smtpPort);

			}
			
			protected override void TearDown()
			{
				smtp = null;
			}
			
			// ---------------------------------------------------------------			
		
			// Test Smtp class below:

			public void TestSmtpHost()
			{
				smtp.Host = smtpHost;
				AssertEquals(smtpHost, smtp.Host);
			}

			public void TestSmtpPort()
			{
				smtp.Port = smtpPort;
				AssertEquals(smtpPort, smtp.Port);
			}
			
			public void TestSendTimeout()
			{
				smtp.SendTimeout = sendTimeout;
				AssertEquals(sendTimeout, smtp.SendTimeout);
			}

			public void TestRecieveTimeout()
			{
				smtp.RecieveTimeout = recieveTimeout;
				AssertEquals(recieveTimeout, smtp.RecieveTimeout);
			}

			public void TestSend()
			{
				try
				{
					msg 			= new MailMessage(senderAddress, recipientAddress);
					msg.ReplyTo 	= replyToAddress;
					msg.From		= senderAddress;

					msg.AddRecipient(additionalAddress, EmailAddress.TO);
					msg.AddRecipient(ccAddress, EmailAddress.CC);
					msg.AddRecipient(bccAddress, EmailAddress.BCC);

					msg.Subject 	= subject;
					msg.Priority 	= MailPriority.HIGH;
					msg.Body		= body;		
				
					smtp.SendMail(msg);
			
				
					
					MailMessage msg2 = new MailMessage(senderAddress, recipientAddress);
					msg2.ReplyTo 	= replyToAddress;
					msg2.From		= senderAddress;

					msg2.AddRecipient(additionalAddress, EmailAddress.TO);
					msg2.AddRecipient(ccAddress, EmailAddress.CC);
					msg2.AddRecipient(bccAddress, EmailAddress.BCC);

					msg2.Subject 	= subject;
					msg2.Priority 	= MailPriority.HIGH;
					msg2.Body		= body;		
				
					Smtp smtp2 = new Smtp(smtpHost, smtpPort);
					smtp2.SendMail(msg);
			
				
				
				}
				catch(SmtpException se)
				{
					Fail("TestSend() threw a SmtpException: " + se.Error);
				}
				catch(Exception e)
				{
					Fail("TestSend threw an Exception: " + e.Message);
				}
			}

    	}
		




}