namespace openSmtp 
{
	/****************************************************
	EmailAddress.cs
	Updated: 1/17/2002
	Author: Ian Stallings - jovian_moon@hotmail.com

	This is a Email Address
	*****************************************************/
	
	using System;
	using System.Text.RegularExpressions;

	public class EmailAddress
	{
		public static readonly int TO = 1;
		public static readonly int CC = 2;
		public static readonly int BCC = 3;

		private string emailAddress;
		private string emailName;

		public EmailAddress(string address)
		{
			checkAddress(address);
			this.emailAddress = address;
		}
		
		public EmailAddress(string address, string name)
		{
			checkAddress(address);
			this.emailAddress = address;
			this.emailName = name;
		}

		public string Address
		{
			get { return(this.emailAddress); }
			set { 
					checkAddress(value);
					this.emailAddress = value; 
				}
		}

		public string Name
		{
			get { return(this.emailName); }
			set { this.emailName = value; }
		}
		
		private bool checkAddress(string address)
		{
			//make sure the address fits valid format (very basic check).
			Regex r = new Regex(@"^[\w-]+@[\w-]+\.", RegexOptions.IgnoreCase); 
			return r.IsMatch(address);
		}

	}
}