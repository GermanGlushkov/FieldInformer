namespace openSmtp 
{

/****************************************************
Log.cs
Updated: 1/21/2002
Author: Ian Stallings - jovian_moon@hotmail.com

This is a Log class. You can log text messages to a 
text file and/or the event log
*****************************************************/

using System;
using System.IO;
using System.Diagnostics;
 
 	// this logging utility was created to log errors, or other 
	public class Log
	{
		
		internal Log() 
		{}
		
		/**
		* Logs string message to EventLog
		*/
 		internal void logToEventLog(String msg, String source)
		{
			//Create the source, if it does not already exist.
			if(!EventLog.SourceExists(source)){
				EventLog.CreateEventSource(source, "Application");
				Console.WriteLine(msg);
			}

			//Create an EventLog instance and assign its source.
			EventLog log = new EventLog();
			log.Log = "Application";
			log.Source = source;

			//Write an informational entry to the event log.    
			log.WriteEntry(msg, EventLogEntryType.Error);
		}
		
		/**
		* Logs string message to TextFile
		*/
		internal void logToTextFile(String path, String msg, String source)
		{
			StreamWriter sw = File.AppendText(path);
			sw.Write(source + msg);
			sw.Close();
		}

	}

}