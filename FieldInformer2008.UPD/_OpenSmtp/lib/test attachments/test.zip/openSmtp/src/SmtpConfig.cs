namespace openSmtp 
{

using System;
using System.Configuration;

	/****************************************************
	SmtpConfig.cs
	Updated: 1/21/2002
	Author: Ian Stallings - jovian_moon@hotmail.com

	This is a SmtpConfig class that stores the configuration
	for the smtp class.
	*****************************************************/

	/**
	*
	* Configuration class that reads configuration from xml file
	* The intention is to give admins the ability to override developer settings
	* such as in the case of an ISP providing hosting.
	*
	**/
	public class SmtpConfig
	{
		/* still working on this
		--------------------------
		private static string smtpHost = ConfigurationSettings.AppSettings["primarySmtpHost"];
		private static int smtpPort = Int32.Parse(ConfigurationSettings.AppSettings["primarySmtpPort"]);
		--------------------------
		*/
		public static readonly string SMTP_HOST = "localhost";
		public static readonly int SMTP_PORT = 25;
		public static readonly string SMTP_LOG_PATH = @"c:\inetpub\wwwroot\asp.net\smtp\SmtpLog.txt";
		public static readonly bool EVENT_LOG = false;

		private SmtpConfig()
		{}

	}
}