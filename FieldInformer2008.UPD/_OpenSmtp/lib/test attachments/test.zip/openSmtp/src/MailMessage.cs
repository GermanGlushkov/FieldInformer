namespace openSmtp 
{

/****************************************************
MailMessage.cs
Updated: 1/21/2002
Author: Ian Stallings - jovian_moon@hotmail.com

This is a MailMessage class that stores the 
message and addresses to be sent via smtp.
*****************************************************/


using System;
using System.Collections;
using System.IO;

	public class MailMessage 
	{
		private EmailAddress	senderEmailAddress;
		private EmailAddress	replyToEmailAddress;
		private ArrayList		recipientList;
		private ArrayList		ccList;
		private ArrayList		bccList;
		private string			subject;
		private string			body;
		private string 			priority;
		
		
		private MailMessage() 
		{}
	
		public MailMessage(EmailAddress sender, EmailAddress recipient) 
		{
			senderEmailAddress = sender;
			replyToEmailAddress = sender;
			
			
			recipientList = new ArrayList();
			recipientList.Add(recipient);
			
			ccList = new ArrayList();		
			bccList = new ArrayList();
		}
		
		public MailMessage(string senderAddress, string recipientAddress) 
		{
			EmailAddress sender = new EmailAddress(senderAddress);
			EmailAddress recipient = new EmailAddress(recipientAddress);
			recipientList = new ArrayList();
			recipientList.Add(recipient);

			ccList = new ArrayList();
			bccList = new ArrayList();
		}


		// -------------------------- Properties --------------------------
		public EmailAddress ReplyTo
		{
			get { return replyToEmailAddress != null ? replyToEmailAddress : senderEmailAddress; }
			set { replyToEmailAddress = value; }
		}	

		public EmailAddress From
		{
			get { return senderEmailAddress; }
			set { senderEmailAddress = value; }
		}	

		public ArrayList To
		{
			get { return recipientList; }
			set { recipientList = value; }
		}
		
		public string Subject
		{
			get { return subject; }
			set { subject = value; }
		}			

		public string Body
		{
			get { return body; }
			set { body = value; }
		}


		public string Priority
		{
			get { return priority; }
			set { priority = value; }
		}

		public ArrayList CC
		{
			get { return ccList; }
			set { ccList = value; }
		}

		public ArrayList BCC
		{
			get { return bccList; }
			set { bccList = value; }
		}

		public void AddRecipient(EmailAddress address, int type)
		{
			try
			{
				if (type == EmailAddress.TO)
				{

					recipientList.Add(address);
				}

				else if (type == EmailAddress.CC)
				{
					ccList.Add(address);
				}

				else if (type ==  EmailAddress.BCC)
				{
					bccList.Add(address);
				}
			}
			catch(Exception e)
			{
				throw new SmtpException("exception in addRecipients: " + e.ToString());
			}
		}
		

		// ------------------------------------------------------------
		
		// Coming Next version. Usually left out but I am forgetful 
		
		/*
		public void SaveMessage(string path)
		{
			
			StreamWriter sw = File.AppendText(path);
			sw.WriteLine();
			sw.Close();
			
		}
		*/
		
	}
}